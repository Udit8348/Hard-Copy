// this the util files

void setup(){
  char kP = (5 > 6 ? 'y': 'q');
}
